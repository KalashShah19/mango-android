package com.example.mango;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    String name, address, mobile, type;
    int qty, price;
    Button btnSave;
    EditText txtName, txtMobile, txtAddress, txtQty, txtPrice, txtDate;
    TextView lblTotal;
    Spinner sType;
    ListView lvData;

    private static String addURL = "http://shahmango.42web.io/api.php";
    private static String getURL = "http://shahmango.42web.io/data.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
        getData();
        calc();
    }

    public void print(String text) {
        Toast.makeText(getApplicationContext(), text, Toast.LENGTH_LONG).show();
    }

    public void init() {
        btnSave = findViewById(R.id.btnSave);
        txtAddress = findViewById(R.id.txtAddress);
        txtMobile = findViewById(R.id.txtMobile);
        txtName = findViewById(R.id.txtName);
        txtQty = findViewById(R.id.txtQty);
        txtPrice = findViewById(R.id.txtPrice);
        lblTotal = findViewById(R.id.total);
        sType = findViewById(R.id.type);
        txtDate = findViewById(R.id.txtDate);
        lvData = findViewById(R.id.lvData);
    }

    public void ButtonClicks() {
        name = txtName.getText().toString();
        address = txtAddress.getText().toString();
        mobile = txtMobile.getText().toString();
        type = sType.getSelectedItem().toString();
        qty = Integer.parseInt(txtQty.getText().toString());
        price = Integer.parseInt(txtPrice.getText().toString());


        print("Order Recorded Successfully.");
    }

    public void calc() {
        txtPrice.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
            }

            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start, int before, int count) {
                price = Integer.parseInt(s.toString());
                qty = Integer.parseInt(txtQty.getText().toString());
                int total = price * qty;
                lblTotal.setText("" + total);
            }
        });
    }

    private void getData() {
        StringRequest request = new StringRequest(Request.Method.GET, getURL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONArray dataArray = new JSONArray(response);
                            ArrayList<String> datalist = new ArrayList<String>();
                            for (int i = 0; i < dataArray.length(); i++) {
                                JSONObject dataObject = dataArray.getJSONObject(i);
                                datalist.add(dataObject.getString("name") +
                                        "," + dataObject.getString("payment") +
                                        "," + dataObject.getString("amount") +
                                        "," + dataObject.getString("mobile") +
                                        "," + dataObject.getString("address") +
                                        "," + dataObject.getString("date") +
                                        "," + dataObject.getString("delivered") +
                                        "," + dataObject.getString("quantity") +
                                        "," + dataObject.getString("type"));
                            }

                            ArrayAdapter<String> adapter = new ArrayAdapter<String>(getApplicationContext(),
                                    android.R.layout.simple_list_item_1, datalist);
                            lvData.setAdapter(adapter);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                print(""+error.toString());
                System.out.println(""+error.toString());
            }
        });
        RequestQueue queue = Volley.newRequestQueue(getApplicationContext());
        queue.add(request);
    }

}
